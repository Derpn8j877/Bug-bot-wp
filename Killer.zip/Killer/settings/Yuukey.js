module.exports = {
  BOT_TOKEN: "8054886637:AAHWRyF9MFrbdkzJ9uhcIjZTv64KizBSoqY",
    YuukeyOwnerId: ['7605667127'],
};